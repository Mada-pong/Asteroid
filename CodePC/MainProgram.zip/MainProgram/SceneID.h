#pragma once

enum sceneID
{
	START,
	ASTEROIDGAME,
	GAMEOVER,
	SCORE,
	STAY
};